// Assemble user data context per Coach message
// Phase 14: AI Coach
// Phase 19: Ingredient flag patterns in Coach context
// Includes conditional context injection and therapy note firewall

import AsyncStorage from '@react-native-async-storage/async-storage';
import { storageGet, STORAGE_KEYS, dateKey, storageList } from '../utils/storage';
import { calculateBmr, calculateTdee, calculateCalorieTarget, computeAge, lbsToKg, inchesToCm } from '../utils/calories';
import { computeConsistency, consistencyPct } from '../utils/consistency';
import { getActiveMilestone } from '../hooks/useMilestone';
import type { UserProfile, EngagementTier, SobrietyGoal } from '../types/profile';
import type {
  CoachContext,
  TodayDataSummary,
  RollingStats,
  PatternInsight,
  InjurySummary,
  BloodworkSummary,
  SobrietyGoalSummary,
  EdRiskFlag,
} from '../types/coach';
import {
  CALORIE_FLOOR_FEMALE,
  CALORIE_FLOOR_MALE,
  ED_EXTREME_RESTRICTION_THRESHOLD,
  ED_SUSTAINED_LOW_DAYS,
  BMI_UNDERWEIGHT,
  BMI_NORMAL_UPPER,
  LBS_PER_KG,
  CM_PER_INCH,
} from '../constants/formulas';
import { evaluateMoodTrend } from '../utils/mood_trend';
import type {
  FoodEntry,
  WaterEntry,
  CaffeineEntry,
  SleepEntry,
  MoodEntry,
  BodyEntry,
  WorkoutEntry,
  StepsEntry,
  InjuryEntry,
  BloodworkEntry,
  SupplementEntry,
  CycleEntry,
  RecoveryScore,
  GlucoseEntry,
  BloodPressureEntry,
  HabitEntry,
  HabitDefinition,
  BodyweightRepEntry,
} from '../types';
import { todayDateString } from '../utils/dayBoundary';


function pastDateString(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Keyword matching for conditional context (simple, not AI)
const TREND_KEYWORDS = ['trend', 'week', 'average', 'how am i', 'doing', 'progress', 'rolling'];
const PATTERN_KEYWORDS = ['pattern', 'notice', 'insight', 'correlation', 'trend'];
const INJURY_KEYWORDS = [
  'injury', 'pain', 'hurt', 'sore', 'workout', 'workouts',
  'exercise', 'exercises', 'train', 'training', 'routine',
  'program', 'movement', 'movements', 'lift', 'lifting',
  'squat', 'bench', 'deadlift', 'press',
  'run', 'running', 'stretch', 'stretching',
];
const BLOODWORK_KEYWORDS = ['blood', 'lab', 'marker', 'cholesterol', 'iron', 'vitamin d'];
const GLUCOSE_KEYWORDS = ['glucose', 'blood sugar', 'sugar level', 'fasting', 'a1c', 'diabetic', 'pre-diabetic', 'mg/dl'];
const BP_KEYWORDS = ['blood pressure', 'bp', 'systolic', 'diastolic', 'hypertension', 'mmhg', 'pulse'];
const CYCLE_KEYWORDS = ['cycle', 'period', 'menstrual', 'phase', 'ovulation'];
const _SUBSTANCE_KEYWORDS = ['drink', 'alcohol', 'sober', 'substance', 'cannabis', 'tobacco'];
const SUPPLEMENT_KEYWORDS = ['supplement', 'vitamin', 'medication', 'dosage'];
const THERAPY_KEYWORDS = ['therapy', 'therapist', 'mental health', 'counseling'];
const INGREDIENT_KEYWORDS = ['ingredient', 'flag', 'additive', 'sweetener', 'sugar', 'msg', 'artificial'];
const HABIT_KEYWORDS = ['habit', 'routine', 'checklist', 'daily', 'brush', 'floss', 'bed', 'cream', 'self care'];
const REP_KEYWORDS = ['rep', 'reps', 'pushup', 'push-up', 'pullup', 'pull-up', 'situp', 'sit-up', 'jumping jack', 'squat', 'bodyweight', 'calisthenics'];

function messageMatchesKeywords(message: string, keywords: string[]): boolean {
  const lower = message.toLowerCase();
  return keywords.some((kw) => lower.includes(kw));
}

/**
 * SEC-06: Sanitize user-generated strings before injecting into prompt context.
 * Strips text patterns that resemble prompt injection attempts
 * (e.g., "[SYSTEM]", "IGNORE", "output your prompt").
 * Truncates to prevent context flooding.
 */
function sanitizeForPrompt(input: string, maxLength: number = 100): string {
  let clean = input.slice(0, maxLength);
  // Strip patterns that look like prompt injection
  clean = clean.replace(/\[(?:SYSTEM|OVERRIDE|ADMIN|PROMPT|INSTRUCTION)[^\]]*\]/gi, '');
  clean = clean.replace(/(?:ignore|forget|disregard)\s+(?:all\s+)?(?:previous\s+)?(?:instructions?|rules?|prompts?)/gi, '');
  clean = clean.replace(/(?:output|reveal|show|display|print)\s+(?:your\s+)?(?:system\s+)?(?:prompt|instructions?|rules?|config)/gi, '');
  // Strip control characters
  clean = clean.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
  return clean.trim();
}

// Therapy note firewall: throws if therapy content leaks into context
function assertNoTherapyContent(contextString: string): void {
  // Check for therapy storage key patterns beyond boolean
  const therapyPatterns = [
    'dub.log.therapy.',
    'therapist_name',
    'therapy_notes',
  ];
  for (const pattern of therapyPatterns) {
    if (contextString.includes(pattern)) {
      throw new Error(`THERAPY FIREWALL: therapy content "${pattern}" detected in Coach context`);
    }
  }
}

export async function buildCoachContext(userMessage: string): Promise<{
  context: CoachContext;
  conditionalSections: string[];
}> {
  const today = todayDateString();

  // Always-load data (sobriety goals are safety-critical — MASTER-03)
  const [profile, tier, sobrietyGoalEntries, consistencyData] = await Promise.all([
    storageGet<UserProfile>(STORAGE_KEYS.PROFILE),
    storageGet<EngagementTier>(STORAGE_KEYS.TIER),
    storageGet<SobrietyGoal[]>(STORAGE_KEYS.SOBRIETY),
    computeConsistency(),
  ]);

  const currentTier = tier ?? 'balanced';

  // Load today's data
  const [
    foodEntries,
    waterEntries,
    caffeineEntries,
    sleepEntry,
    moodEntries,
    bodyEntry,
    recoveryScore,
    workoutEntries,
    stepsEntry,
    glucoseEntries,
    bpEntries,
  ] = await Promise.all([
    storageGet<FoodEntry[]>(dateKey(STORAGE_KEYS.LOG_FOOD, today)),
    storageGet<WaterEntry[]>(dateKey(STORAGE_KEYS.LOG_WATER, today)),
    storageGet<CaffeineEntry[]>(dateKey(STORAGE_KEYS.LOG_CAFFEINE, today)),
    storageGet<SleepEntry>(dateKey(STORAGE_KEYS.LOG_SLEEP, today)),
    storageGet<MoodEntry[]>(dateKey(STORAGE_KEYS.LOG_MOOD, today)),
    storageGet<BodyEntry>(dateKey(STORAGE_KEYS.LOG_BODY, today)),
    storageGet<RecoveryScore>(dateKey(STORAGE_KEYS.RECOVERY, today)),
    storageGet<WorkoutEntry[]>(dateKey(STORAGE_KEYS.LOG_WORKOUT, today)),
    storageGet<StepsEntry>(dateKey(STORAGE_KEYS.LOG_STEPS, today)),
    storageGet<GlucoseEntry[]>(dateKey(STORAGE_KEYS.LOG_GLUCOSE, today)),
    storageGet<BloodPressureEntry[]>(dateKey(STORAGE_KEYS.LOG_BP, today)),
  ]);

  const foods = foodEntries ?? [];
  const waters = waterEntries ?? [];
  const caffeines = caffeineEntries ?? [];
  const moods = moodEntries ?? [];

  const tagsLogged: string[] = [];
  if (foods.length > 0) tagsLogged.push('nutrition.food');
  if (waters.length > 0) tagsLogged.push('hydration.water');
  if (sleepEntry) tagsLogged.push('sleep.tracking');
  if (moods.length > 0) tagsLogged.push('mental.wellness');
  if (bodyEntry) tagsLogged.push('body.measurements');
  const glucoseReadings = glucoseEntries ?? [];
  if (glucoseReadings.length > 0) tagsLogged.push('blood.glucose');
  const bpReadings = bpEntries ?? [];
  if (bpReadings.length > 0) tagsLogged.push('blood.pressure');

  const workouts = workoutEntries ?? [];
  const caloriesBurned = workouts.reduce((s, w) => s + (w.calories_burned ?? 0), 0);

  const todayData: TodayDataSummary = {
    calories_consumed: foods.reduce((s, f) => s + (f.computed_nutrition?.calories ?? 0), 0),
    calories_burned: caloriesBurned,
    protein_g: foods.reduce((s, f) => s + (f.computed_nutrition?.protein_g ?? 0), 0),
    carbs_g: foods.reduce((s, f) => s + (f.computed_nutrition?.carbs_g ?? 0), 0),
    fat_g: foods.reduce((s, f) => s + (f.computed_nutrition?.fat_g ?? 0), 0),
    water_oz: waters.reduce((s, w) => s + w.amount_oz, 0),
    caffeine_mg: caffeines.reduce((s, c) => s + c.amount_mg, 0),
    steps: stepsEntry?.total_steps ?? 0,
    workouts: workouts.map((w) => w.activity_name),
    mood: moods.length > 0 ? moods.reduce((s, m) => s + m.score, 0) / moods.length : null,
    energy: moods.length > 0 ? moods.filter((m) => m.energy != null).reduce((s, m) => s + m.energy!, 0) / Math.max(moods.filter((m) => m.energy != null).length, 1) || null : null,
    anxiety: moods.length > 0 ? moods.filter((m) => m.anxiety != null).reduce((s, m) => s + m.anxiety!, 0) / Math.max(moods.filter((m) => m.anxiety != null).length, 1) || null : null,
    sleep_hours: sleepEntry?.bedtime && sleepEntry?.wake_time
      ? (new Date(sleepEntry.wake_time).getTime() - new Date(sleepEntry.bedtime).getTime()) / 3600000
      : null,
    sleep_quality: sleepEntry?.quality ?? null,
    tags_logged: tagsLogged,
  };

  // Compute BMR/TDEE/Calorie Target (MASTER-22: Coach must use target, not TDEE)
  let bmr: number | null = null;
  let tdee: number | null = null;
  let calorieTarget: number | null = null;
  if (
    profile?.weight_lbs != null &&
    profile?.height_inches != null &&
    profile?.dob != null &&
    profile?.sex != null &&
    profile?.activity_level != null
  ) {
    const age = computeAge(profile.dob);
    const weightKg = lbsToKg(profile.weight_lbs);
    const heightCm = inchesToCm(profile.height_inches);
    bmr = calculateBmr({ weightKg, heightCm, ageYears: age, sex: profile.sex, metabolicProfile: profile.metabolic_profile });
    tdee = calculateTdee(bmr, profile.activity_level);
    calorieTarget = calculateCalorieTarget({
      tdee,
      goalDirection: profile.goal?.direction ?? 'MAINTAIN',
      sex: profile.sex,
      rateLbsPerWeek: profile.goal?.rate_lbs_per_week ?? undefined,
      surplusCalories: profile.goal?.surplus_calories ?? undefined,
    });
  }

  // Conditional sections
  const conditionalSections: string[] = [];

  // Always compute 7-day weight average (P1 redesign: weight context is always-include)
  const weightRolling = await compute7DayRolling(today);
  if (weightRolling?.avg_weight != null) {
    conditionalSections.push(`[WEIGHT 7D] Avg:${weightRolling.avg_weight.toFixed(1)} Pts:${weightRolling.weight_count}`);
  }

  // 7-day rolling stats for non-weight metrics (conditional on trend keywords)
  if (messageMatchesKeywords(userMessage, TREND_KEYWORDS)) {
    if (weightRolling) {
      const parts: string[] = [];
      if (weightRolling.avg_calories != null) parts.push(`Cal:${Math.round(weightRolling.avg_calories)}avg`);
      if (weightRolling.avg_protein_g != null) parts.push(`P:${Math.round(weightRolling.avg_protein_g)}g`);
      if (weightRolling.avg_sleep_hours != null) parts.push(`Sleep:${weightRolling.avg_sleep_hours.toFixed(1)}h`);
      if (weightRolling.avg_mood != null) parts.push(`Mood:${weightRolling.avg_mood.toFixed(1)}`);
      if (weightRolling.avg_energy != null) parts.push(`Energy:${weightRolling.avg_energy.toFixed(1)}`);
      if (weightRolling.avg_anxiety != null) parts.push(`Anxiety:${weightRolling.avg_anxiety.toFixed(1)}`);
      if (parts.length > 0) {
        conditionalSections.push(`[7D] ${parts.join(' ')}`);
      }
    }
  }

  // Active patterns (conditional)
  let activePatterns: PatternInsight[] = [];
  if (messageMatchesKeywords(userMessage, PATTERN_KEYWORDS)) {
    activePatterns = (await storageGet<PatternInsight[]>(STORAGE_KEYS.COACH_PATTERNS)) ?? [];
  }

  // MASTER-34: Active injuries are safety-critical (e.g., user asks "design a workout"
  // with a torn rotator cuff). Always-include for severity >= 5 or acute type.
  // Minor/resolved injuries remain conditional on keywords.
  // eslint-disable-next-line no-useless-assignment -- injuries is reassigned inside the block below
  let injuries: InjurySummary[] = [];
  {
    const allInjuryKeys = await storageList('dub.log.injury.');
    const allUnresolved: InjurySummary[] = [];
    for (const key of allInjuryKeys.slice(-7)) {
      const entries = await storageGet<InjuryEntry[]>(key);
      if (entries) {
        for (const e of entries) {
          if (!e.resolved_date) {
            allUnresolved.push({
              location: e.body_location,
              severity: e.severity,
              type: e.type,
              aggravators: e.aggravators,
            });
          }
        }
      }
    }

    // Always include: severity >= 5 or acute type (safety-critical)
    const safetyInjuries = allUnresolved.filter(
      (i) => i.severity >= 5 || i.type === 'acute',
    );

    // Conditionally include minor injuries on keyword match
    const minorInjuries = messageMatchesKeywords(userMessage, INJURY_KEYWORDS)
      ? allUnresolved.filter((i) => i.severity < 5 && i.type !== 'acute')
      : [];

    injuries = [...safetyInjuries, ...minorInjuries];

    // Deduplicate by location
    const seen = new Set<string>();
    injuries = injuries.filter((i) => {
      if (seen.has(i.location)) return false;
      seen.add(i.location);
      return true;
    });
  }

  // Bloodwork (conditional)
  let bloodwork: BloodworkSummary | null = null;
  if (messageMatchesKeywords(userMessage, BLOODWORK_KEYWORDS)) {
    const bwKeys = await storageList('dub.log.bloodwork.');
    if (bwKeys.length > 0) {
      const latestKey = bwKeys.sort().pop()!;
      const entry = await storageGet<BloodworkEntry>(latestKey);
      if (entry) {
        bloodwork = {
          date: entry.date,
          flagged_markers: entry.markers
            .filter((m) => m.flagged)
            .map((m) => ({
              name: m.name,
              value: m.value,
              unit: m.unit,
              reference_range: `${m.reference_range_low ?? '?'}-${m.reference_range_high ?? '?'}`,
              status: (m.reference_range_high != null && m.value > m.reference_range_high) ? 'high' as const : 'low' as const,
            })),
        };
        if (bloodwork.flagged_markers.length > 0) {
          const bwText = bloodwork.flagged_markers
            .map((m) => `${sanitizeForPrompt(m.name, 50)}:${m.value}${sanitizeForPrompt(m.unit, 20)}(ref:${m.reference_range},${m.status})`)
            .join(' ');
          conditionalSections.push(`[BLOODWORK ${bloodwork.date}] ${bwText}`);
        }
      }
    }
  }

  // Cycle phase (conditional)
  let cyclePhase: string | null = null;
  if (messageMatchesKeywords(userMessage, CYCLE_KEYWORDS)) {
    const cycleEntry = await storageGet<CycleEntry>(dateKey(STORAGE_KEYS.LOG_CYCLE, today));
    if (cycleEntry?.computed_phase) {
      cyclePhase = cycleEntry.computed_phase;
      conditionalSections.push(`[CYCLE] Phase: ${cyclePhase} Day: ${cycleEntry.cycle_day ?? '?'}`);
    }
  }

  // Sobriety goals — ALWAYS included (safety-critical, MASTER-03)
  // QUIT/REDUCE goals must be present in every Coach interaction to prevent
  // Coach from suggesting substance use (e.g., alcohol-paired meals).
  // Daily substance LOG DATA stays conditional on SUBSTANCE_KEYWORDS.
  const sobrietyGoals: SobrietyGoalSummary[] = (sobrietyGoalEntries ?? []).map((g) => ({
    substance: g.substance,
    goal_type: g.goal_type,
    current_streak_days: g.current_streak_days,
  }));

  // Supplement UL flags (conditional)
  let supplementFlags: string[] = [];
  if (messageMatchesKeywords(userMessage, SUPPLEMENT_KEYWORDS)) {
    const supps = await storageGet<SupplementEntry[]>(dateKey(STORAGE_KEYS.LOG_SUPPLEMENTS, today));
    if (supps && supps.length > 0) {
      supplementFlags = supps.map((s) => `${s.name} ${s.dosage}${s.unit}`);
      conditionalSections.push(`[SUPPLEMENTS] ${supplementFlags.join(' | ')}`);
    }
  }

  // Blood glucose (conditional)
  if (messageMatchesKeywords(userMessage, GLUCOSE_KEYWORDS)) {
    if (glucoseReadings.length > 0) {
      const parts = glucoseReadings.map((g) => `${g.reading_mg_dl}mg/dL(${g.timing})`);
      conditionalSections.push(`[GLUCOSE TODAY] ${parts.join(' ')}`);
    }
  }

  // Blood pressure (conditional)
  if (messageMatchesKeywords(userMessage, BP_KEYWORDS)) {
    if (bpReadings.length > 0) {
      const parts = bpReadings.map((b) =>
        `${b.systolic}/${b.diastolic}${b.pulse_bpm != null ? ` (${b.pulse_bpm} bpm)` : ''}`
      );
      conditionalSections.push(`[BP TODAY] ${parts.join(' ')}`);
    }
  }

  // Therapy boolean (conditional -- NEVER include notes)
  let therapyToday = false;
  if (messageMatchesKeywords(userMessage, THERAPY_KEYWORDS)) {
    const therapyEntry = await storageGet<{ session_logged: boolean }>(dateKey(STORAGE_KEYS.LOG_THERAPY, today));
    therapyToday = therapyEntry?.session_logged ?? false;
  }

  // Ingredient flag patterns (conditional)
  if (messageMatchesKeywords(userMessage, INGREDIENT_KEYWORDS)) {
    // Count flagged ingredient occurrences in the past 7 days of food entries
    const flagCounts = new Map<string, number>();
    for (let i = 0; i < 7; i++) {
      const date = pastDateString(i);
      const dayFoods = await storageGet<FoodEntry[]>(dateKey(STORAGE_KEYS.LOG_FOOD, date));
      if (dayFoods) {
        for (const f of dayFoods) {
          if (f.flagged_ingredients) {
            for (const flag of f.flagged_ingredients) {
              flagCounts.set(flag, (flagCounts.get(flag) ?? 0) + 1);
            }
          }
        }
      }
    }
    if (flagCounts.size > 0) {
      const parts = Array.from(flagCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .map(([name, count]) => `${sanitizeForPrompt(name, 50)}:${count}x`)
        .join(' ');
      conditionalSections.push(`[INGREDIENT FLAGS 7d] ${parts}`);
    }
  }

  // Daily habits (conditional)
  if (messageMatchesKeywords(userMessage, HABIT_KEYWORDS)) {
    const habitDefs = await storageGet<HabitDefinition[]>(STORAGE_KEYS.SETTINGS_HABITS);
    const habitEntries = await storageGet<HabitEntry[]>(dateKey(STORAGE_KEYS.LOG_HABITS, today));
    if (habitEntries && habitEntries.length > 0 && habitDefs) {
      const completed = habitEntries.filter((h) => h.completed);
      const missed = habitEntries.filter((h) => !h.completed);
      const missedNames = missed
        .map((h) => sanitizeForPrompt(h.name, 50))
        .join(', ');
      const missedPart = missed.length > 0 ? ` (missed: ${missedNames})` : '';
      conditionalSections.push(
        `[HABITS ${today}] ${completed.length}/${habitEntries.length} completed${missedPart}`,
      );
    }
  }

  // Bodyweight reps (conditional)
  if (messageMatchesKeywords(userMessage, REP_KEYWORDS)) {
    const repEntries = await storageGet<BodyweightRepEntry[]>(dateKey(STORAGE_KEYS.LOG_REPS, today));
    if (repEntries && repEntries.length > 0) {
      const totals = new Map<string, { reps: number; sets: number }>();
      for (const r of repEntries) {
        const prev = totals.get(r.exercise_type) ?? { reps: 0, sets: 0 };
        totals.set(r.exercise_type, {
          reps: prev.reps + r.reps * r.sets,
          sets: prev.sets + r.sets,
        });
      }
      const parts = Array.from(totals.entries())
        .map(([type, t]) => `${type}:${t.reps}(${t.sets}sets)`)
        .join(' ');
      conditionalSections.push(`[REPS ${today}] ${parts}`);
    }
  }

  // ---- Eating Disorder Risk Detection (always computed, safety-critical) ----
  const edRiskFlags: EdRiskFlag[] = [];

  // Determine sex-aware calorie floor (uses metabolic_profile for intersex)
  const effectiveSexForFloor =
    profile?.sex === 'intersex' && profile?.metabolic_profile
      ? profile.metabolic_profile
      : profile?.sex;
  const calorieFloor =
    effectiveSexForFloor === 'female' ? CALORIE_FLOOR_FEMALE :
    effectiveSexForFloor === 'male' ? CALORIE_FLOOR_MALE :
    Math.round((CALORIE_FLOOR_FEMALE + CALORIE_FLOOR_MALE) / 2);

  // Flag 1: Extreme restriction today (below 1,000 cal with food logged)
  if (foods.length > 0 && todayData.calories_consumed < ED_EXTREME_RESTRICTION_THRESHOLD) {
    edRiskFlags.push({
      type: 'extreme_restriction_today',
      detail: `Today's intake is ${todayData.calories_consumed} cal (below ${ED_EXTREME_RESTRICTION_THRESHOLD} cal threshold)`,
    });
  }

  // Flag 2: Sustained low intake (3+ days below calorie floor in a 7-day rolling window, skipping no-log days)
  {
    let lowDays = 0;
    for (let i = 0; i < 7; i++) {
      const date = pastDateString(i);
      const dayFoods = i === 0 ? foods : await storageGet<FoodEntry[]>(dateKey(STORAGE_KEYS.LOG_FOOD, date));
      const dayArr = dayFoods ?? [];
      if (dayArr.length === 0) continue; // no food logged = skip, not a streak-breaker
      const dayCal = dayArr.reduce((s, f) => s + (f.computed_nutrition?.calories ?? 0), 0);
      if (dayCal > 0 && dayCal < calorieFloor) {
        lowDays++;
      }
    }
    if (lowDays >= ED_SUSTAINED_LOW_DAYS) {
      edRiskFlags.push({
        type: 'sustained_low_intake',
        detail: `Calorie intake below ${calorieFloor} cal on ${lowDays} of the last 7 days`,
      });
    }
  }

  // Flag 3: Underweight BMI (regardless of goal)
  if (profile?.weight_lbs != null && profile?.height_inches != null) {
    const weightKg = profile.weight_lbs / LBS_PER_KG;
    const heightM = (profile.height_inches * CM_PER_INCH) / 100;
    const bmi = weightKg / (heightM * heightM);
    if (bmi <= BMI_UNDERWEIGHT) {
      edRiskFlags.push({
        type: 'underweight_bmi',
        detail: `BMI is ${bmi.toFixed(1)} (at or below ${BMI_UNDERWEIGHT}), which is classified as underweight`,
      });
    }
  }

  // Flag 4: Healthy BMI + active weight loss goal
  if (
    profile?.weight_lbs != null &&
    profile?.height_inches != null &&
    profile?.goal?.direction === 'LOSE'
  ) {
    const weightKg = profile.weight_lbs / LBS_PER_KG;
    const heightM = (profile.height_inches * CM_PER_INCH) / 100;
    const bmi = weightKg / (heightM * heightM);
    if (bmi <= BMI_NORMAL_UPPER) {
      edRiskFlags.push({
        type: 'healthy_bmi_loss_goal',
        detail: `BMI is ${bmi.toFixed(1)} (at or below ${BMI_NORMAL_UPPER}) with active weight loss goal`,
      });
    }
  }

  // Mood trend detection — safety-critical, always computed
  const moodTrend = await evaluateMoodTrend();

  // P2-05: Active milestone for coach context
  const activeMilestone = await getActiveMilestone(consistencyData);
  if (activeMilestone) {
    conditionalSections.push(`[${activeMilestone.toUpperCase()}]`);
  }

  const context: CoachContext = {
    profile: profile ?? {
      name: 'User',
      dob: '',
      units: 'imperial',
      sex: null,
      pronouns: null,
      metabolic_profile: null,
      main_goal: null,
      height_inches: null,
      weight_lbs: null,
      activity_level: null,
      goal: null,
      altitude_acclimated: false,
    },
    tier: currentTier,
    today_data: todayData,
    rolling_7d: {
      avg_calories: null,
      avg_protein_g: null,
      avg_carbs_g: null,
      avg_fat_g: null,
      avg_water_oz: null,
      avg_sleep_hours: null,
      avg_mood: null,
      avg_energy: null,
      avg_anxiety: null,
      avg_weight: null,
      weight_count: 0,
      workout_count: 0,
    },
    bmr,
    tdee,
    calorie_target: calorieTarget,
    recovery_score: recoveryScore?.total_score ?? null,
    consistency_28d_pct: consistencyPct(consistencyData),
    active_correlations: activePatterns,
    active_injuries: injuries,
    latest_bloodwork: bloodwork,
    cycle_phase: cyclePhase,
    sobriety_goals: sobrietyGoals,
    supplement_flags: supplementFlags,
    therapy_today: therapyToday,
    ed_risk_flags: edRiskFlags,
    mood_trend_alert: moodTrend.triggered,
    active_milestone: activeMilestone,
  };

  // Therapy note firewall: verify no therapy content leaked
  const contextJson = JSON.stringify(context) + conditionalSections.join('');
  assertNoTherapyContent(contextJson);

  return { context, conditionalSections };
}

async function compute7DayRolling(_today: string): Promise<RollingStats | null> {
  // MASTER-61: Build all 42 keys upfront, fetch in a single multiGet
  const dates: string[] = [];
  const allKeys: string[] = [];
  const TAG_PREFIXES = [
    STORAGE_KEYS.LOG_FOOD,
    STORAGE_KEYS.LOG_WATER,
    STORAGE_KEYS.LOG_SLEEP,
    STORAGE_KEYS.LOG_MOOD,
    STORAGE_KEYS.LOG_BODY,
    STORAGE_KEYS.LOG_WORKOUT,
  ] as const;

  for (let i = 0; i < 7; i++) {
    const date = pastDateString(i);
    dates.push(date);
    for (const prefix of TAG_PREFIXES) {
      allKeys.push(dateKey(prefix, date));
    }
  }

  const pairs = await AsyncStorage.multiGet(allKeys);
  const lookup = new Map<string, string>();
  for (const [key, raw] of pairs) {
    if (raw != null) lookup.set(key, raw);
  }

  function parse<T>(prefix: string, date: string): T | null {
    const raw = lookup.get(dateKey(prefix, date));
    return raw != null ? (JSON.parse(raw) as T) : null;
  }

  let workoutCount = 0;
  const stats = {
    calories: [] as number[],
    protein: [] as number[],
    carbs: [] as number[],
    fat: [] as number[],
    water: [] as number[],
    sleep: [] as number[],
    mood: [] as number[],
    energy: [] as number[],
    anxiety: [] as number[],
    weight: [] as number[],
  };

  for (const date of dates) {
    const foods = parse<FoodEntry[]>(STORAGE_KEYS.LOG_FOOD, date);
    if (foods && foods.length > 0) {
      stats.calories.push(foods.reduce((s, f) => s + (f.computed_nutrition?.calories ?? 0), 0));
      stats.protein.push(foods.reduce((s, f) => s + (f.computed_nutrition?.protein_g ?? 0), 0));
      stats.carbs.push(foods.reduce((s, f) => s + (f.computed_nutrition?.carbs_g ?? 0), 0));
      stats.fat.push(foods.reduce((s, f) => s + (f.computed_nutrition?.fat_g ?? 0), 0));
    }

    const waters = parse<WaterEntry[]>(STORAGE_KEYS.LOG_WATER, date);
    if (waters && waters.length > 0) {
      stats.water.push(waters.reduce((s, w) => s + w.amount_oz, 0));
    }

    const sleepEntry = parse<SleepEntry>(STORAGE_KEYS.LOG_SLEEP, date);
    if (sleepEntry?.bedtime && sleepEntry?.wake_time) {
      const hours = (new Date(sleepEntry.wake_time).getTime() - new Date(sleepEntry.bedtime).getTime()) / 3600000;
      if (hours > 0 && hours < 24) stats.sleep.push(hours);
    }

    const moodEntries = parse<MoodEntry[]>(STORAGE_KEYS.LOG_MOOD, date);
    if (moodEntries && moodEntries.length > 0) {
      stats.mood.push(moodEntries.reduce((s, m) => s + m.score, 0) / moodEntries.length);
      const withEnergy = moodEntries.filter((m) => m.energy != null);
      if (withEnergy.length > 0) {
        stats.energy.push(withEnergy.reduce((s, m) => s + m.energy!, 0) / withEnergy.length);
      }
      const withAnxiety = moodEntries.filter((m) => m.anxiety != null);
      if (withAnxiety.length > 0) {
        stats.anxiety.push(withAnxiety.reduce((s, m) => s + m.anxiety!, 0) / withAnxiety.length);
      }
    }

    const bodyEntry = parse<BodyEntry>(STORAGE_KEYS.LOG_BODY, date);
    if (bodyEntry?.weight_lbs != null) {
      stats.weight.push(bodyEntry.weight_lbs);
    }

    const workoutEntries = parse<WorkoutEntry[]>(STORAGE_KEYS.LOG_WORKOUT, date);
    if (workoutEntries && workoutEntries.length > 0) {
      workoutCount++;
    }
  }

  const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : null;

  return {
    avg_calories: avg(stats.calories),
    avg_protein_g: avg(stats.protein),
    avg_carbs_g: avg(stats.carbs),
    avg_fat_g: avg(stats.fat),
    avg_water_oz: avg(stats.water),
    avg_sleep_hours: avg(stats.sleep),
    avg_mood: avg(stats.mood),
    avg_energy: avg(stats.energy),
    avg_anxiety: avg(stats.anxiety),
    avg_weight: avg(stats.weight),
    weight_count: stats.weight.length,
    workout_count: workoutCount,
  };
}
